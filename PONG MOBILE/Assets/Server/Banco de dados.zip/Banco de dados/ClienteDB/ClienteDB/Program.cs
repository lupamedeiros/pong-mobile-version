﻿using System;
using System.Net.Sockets;
using System.Text;

class Client
{
    static void Main()
    {
        string serverAddress = "127.0.0.1"; // Endereço do servidor
        int port = 13000; // A mesma porta do servidor

        try
        {
            TcpClient client = new TcpClient(serverAddress, port);
            NetworkStream stream = client.GetStream();

            Console.WriteLine("Conectado ao servidor!");

            // Solicita o nome do jogador
            Console.Write("Digite o nome do jogador: ");
            string playerName = Console.ReadLine();

            // Envia o nome do jogador para o servidor
            byte[] data = Encoding.ASCII.GetBytes(playerName);
            stream.Write(data, 0, data.Length);

            // Aguarda a resposta do servidor
            byte[] response = new byte[256];
            int bytesRead = stream.Read(response, 0, response.Length);
            string responseData = Encoding.ASCII.GetString(response, 0, bytesRead);
            Console.WriteLine("Resposta do servidor: " + responseData);

            stream.Close();
            client.Close();
        }
        catch (Exception e)
        {
            Console.WriteLine("Erro: {0}", e);
        }

        Console.ReadLine();
    }
}
