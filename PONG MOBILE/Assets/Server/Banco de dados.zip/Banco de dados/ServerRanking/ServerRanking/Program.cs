﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using SQLite;
using System.Collections.Generic;

class Server
{
    static void Main()
    {
        // Caminho do banco de dados
        string dbPath = @"C:\Users\honny\Downloads\DB\jogadores.db";
        TcpListener server = null;
        try
        {
            IPAddress localAddr = IPAddress.Parse("127.0.0.1"); 
            int port = 13000;
            server = new TcpListener(localAddr, port);
            server.Start();
            Console.WriteLine("Servidor iniciado na porta " + port);
            using (var db = new SQLiteConnection(dbPath))
            {
                db.CreateTable<Player>(); 
            }
            DisplayPlayers(dbPath);

            while (true)
            {
                Console.WriteLine("Aguardando conexão...");

                TcpClient client = server.AcceptTcpClient();
                Thread clientThread = new Thread(() => HandleClient(client, dbPath));
                clientThread.Start();
            }
        }
        catch (SocketException e)
        {
            Console.WriteLine("SocketException: {0}", e);
        }
        finally
        {
            server?.Stop();
        }

        Console.WriteLine("\nPressione Enter para continuar...");
        Console.Read();
    }

    // Exibe todos os jogadores do banco de dados, ordenados por score (decrescente)
    public static void DisplayPlayers(string dbPath)
    {
        using (var db = new SQLiteConnection(dbPath))
        {
            var players = db.Table<Player>().OrderByDescending(p => p.Score).ToList();  // Ordena decrescentemente pelo score

            Console.WriteLine("\nJogadores no banco de dados (ordenados pelo score):");
            if (players.Count > 0)
            {
                foreach (var player in players)
                {
                    Console.WriteLine($"ID: {player.Id}, Nome: {player.Name}, Score: {player.Score}");
                }
            }
            else
            {
                Console.WriteLine("Nenhum jogador encontrado.");
            }
        }
    }
public static void HandleClient(TcpClient client, string dbPath)
{
    NetworkStream stream = client.GetStream();
    byte[] buffer = new byte[256];
    int bytesRead;

    try
    {
        while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0)
        {
            string data = Encoding.ASCII.GetString(buffer, 0, bytesRead);
            Console.WriteLine($"Recebido: {data}");

            if (data.StartsWith("UPDATE_SCORE:"))
            {
                string[] parts = data.Replace("UPDATE_SCORE:", "").Split(',');
                int id = int.Parse(parts[0].Split(':')[1]); // Extrai o ID
                int score = int.Parse(parts[1].Split(':')[1]); // Extrai o Score

                UpdatePlayerScore(dbPath, id, score);

                byte[] msg = Encoding.ASCII.GetBytes("Score atualizado com sucesso.");
                stream.Write(msg, 0, msg.Length);

                DisplayPlayers(dbPath);
            }
            else if (data == "GET_RANK") // Nova funcionalidade para enviar o ranking
            {
                using (var db = new SQLiteConnection(dbPath))
                {
                    var players = db.Table<Player>().OrderByDescending(p => p.Score).ToList();
                    string rankData = "";

                    for (int i = 0; i < players.Count; i++)
                    {
                        rankData += $"{i + 1}:{players[i].Name}:{players[i].Score}|";
                    }

                    rankData = rankData.TrimEnd('|'); // Remove o último "|"
                    byte[] msg = Encoding.ASCII.GetBytes(rankData);
                    stream.Write(msg, 0, msg.Length);

                    Console.WriteLine("Ranking enviado ao cliente.");
                }
            }
            else
            {
                int playerId = AddPlayerToDatabase(dbPath, data);

                // Retorna o ID do jogador ao cliente
                var response = $"ID:{playerId},Name:{data},Score:0";
                byte[] msg = Encoding.ASCII.GetBytes(response);
                stream.Write(msg, 0, msg.Length);

                DisplayPlayers(dbPath);
            }
        }
    }
    catch (Exception e)
    {
        Console.WriteLine("Erro: {0}", e);
    }
    finally
    {
        stream?.Close();
        client.Close();
    }
}


    public static void UpdatePlayerScore(string dbPath, int playerId, int score)
    {
        using (var db = new SQLiteConnection(dbPath))
        {
            var player = db.Table<Player>().FirstOrDefault(p => p.Id == playerId);
            if (player != null)
            {
                player.Score = score;
                db.Update(player);
                Console.WriteLine($"Score do jogador {player.Name} atualizado para {player.Score}.");
            }
            else
            {
                Console.WriteLine("Jogador não encontrado para atualizar o score.");
            }
        }
    }

    // Adiciona um jogador ao banco de dados
    public static int AddPlayerToDatabase(string dbPath, string playerName)
    {
        using (var db = new SQLiteConnection(dbPath))
        {
            // Verifica se o jogador já existe
            var existingPlayer = db.Table<Player>().FirstOrDefault(p => p.Name == playerName);
            if (existingPlayer != null)
            {
                Console.WriteLine($"Jogador já existe: ID={existingPlayer.Id}, Nome={existingPlayer.Name}, Score={existingPlayer.Score}");
                return existingPlayer.Id;
            }

            // Cria um novo jogador
            var newPlayer = new Player { Name = playerName, Score = 0 };
            db.Insert(newPlayer);

            Console.WriteLine($"Novo jogador adicionado: ID={newPlayer.Id}, Nome={newPlayer.Name}, Score={newPlayer.Score}");
            return newPlayer.Id;
        }
    }


}
public class Player
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }
    public string Name { get; set; }
    public int Score { get; set; }
}
